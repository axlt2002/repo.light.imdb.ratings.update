# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################

import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import os, unicodedata
from datetime import datetime

addonSettings = xbmcaddon.Addon( "script.light.imdb.ratings.update" )
addonName     = addonSettings.getAddonInfo( "name" )
addonVersion  = addonSettings.getAddonInfo( "version" )
addonIcon     = os.path.join( addonSettings.getAddonInfo( "path" ), "icon.png" )
addonProfile  = xbmc.translatePath( addonSettings.getAddonInfo( "profile" ) )
addonLanguage = addonSettings.getLocalizedString

onMovies          = addonSettings.getSetting( "Movies" )
onTVShows         = addonSettings.getSetting( "TVShows" )
ShowNotifications = addonSettings.getSetting( "ShowNotifications" )
ShowProgress      = addonSettings.getSetting( "ShowProgress" )
ShowLogMessage    = addonSettings.getSetting( "ShowLogMessage" )
IncludeEpisodes   = addonSettings.getSetting( "IncludeEpisodes" )
IMDbDefault       = addonSettings.getSetting( "IMDbRatingDefault" )
Sound             = addonSettings.getSetting( "NotificationsSound" )
ScheduleEnabled   = addonSettings.getSetting( "ScheduleEnabled" )
ScheduledWeekDay  = addonSettings.getSetting( "ScheduledWeekDay" )
DayTime           = addonSettings.getSetting( "DayTime" )

def_threads = [8, 16, 1, 2, 4]
NumberOfThreads = def_threads[int(addonSettings.getSetting( "NumberOfThreads" ))]

def doUnicode( textMessage ):
    try: textMessage = unicode( textMessage, 'utf-8' )
    except: pass
    return textMessage

def doNormalize( textMessage ):
    try: textMessage = unicodedata.normalize( 'NFKD', doUnicode( textMessage ) ).encode( 'utf-8' )
    except: pass
    return textMessage

def defaultLog( textMessage ):
    xbmc.log( "[%s] - %s" % ( addonName, doNormalize( textMessage ) ) )

def debugLog( textMessage ):
    xbmc.log( "[%s] - %s" % ( addonName, doNormalize( textMessage ) ), level = xbmc.LOGDEBUG )

def doNotify( textMessage, millSec ):
    dialog = xbmcgui.Dialog()
    if Sound == "true":
        playSound = True
    else:
        playSound = False
    dialog.notification(addonName, textMessage, addonIcon, millSec, playSound)

def statusLog( textMessage ):
	f = open( addonProfile + "/update.log", 'ab' )
	f.write( doNormalize( "\n" + textMessage + "\n" ) )
	f.close()

def beginStatusLog():
	if xbmcvfs.exists( addonProfile + "/update.old.log" ):
		os.remove( addonProfile + "/update.old.log" )
	if xbmcvfs.exists( addonProfile + "/update.log" ):
		os.rename( addonProfile + "/update.log", addonProfile + "/update.old.log" )
	f = open( addonProfile + "/update.log", 'wb' )
	f.write( doNormalize( "--------------------------------------------------------\n" ) )
	f.write( doNormalize( "Starting " + addonName + " (" + datetime.now().strftime("%Y-%m-%d %H:%M:%S") + ")\n" ) )
	f.write( doNormalize( "version " + addonVersion + "\n" ) )
	f.write( doNormalize( "onMovies: " + onMovies + "\n" ) )
	f.write( doNormalize( "onTVShows: " + onTVShows + "\n" ) )
	f.write( doNormalize( "IncludeEpisodes: " + IncludeEpisodes + "\n" ) )
	f.write( doNormalize( "IMDbDefault: " + IMDbDefault + "\n" ) )
	f.write( doNormalize( "NumberOfThreads: " + str(NumberOfThreads) + "\n" ) )
	f.write( doNormalize( "ScheduleEnabled: " + ScheduleEnabled + "\n" ) )
	if ScheduleEnabled == "true":
		f.write( doNormalize( addonLanguage(32655) % (ScheduledWeekDay, DayTime) + "\n" ) )
	f.write( doNormalize( "--------------------------------------------------------\n" ) )
	f.close()

def internet():
	try:
		import urllib.request
		urllib.request.urlopen('http://216.58.192.142', timeout=3)
		return True
	except: 
		return False

def wait_for_internet(wait=30, retry=5):
	monitor = xbmc.Monitor()
	count = 0
	while True:
		if internet():
			return True
		count += 1
		if count >= retry or monitor.abortRequested():
			return False
		monitor.waitForAbort(wait)