# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################
# changes by dziobak        #
#############################

from common import *
from requests.exceptions import HTTPError
from requests.exceptions import ConnectionError
import resources.support.tvdbsimple as tvdb
tvdb.KEYS.API_KEY = "53F49B260156B636"

def get_IMDb_ID_from_theTVDB(tvdb_id):
	if tvdb_id == "" or tvdb_id == None or tvdb_id == addonLanguage(32528):
		return (None, "Method get_IMDb_ID_from_theTVDB - Missing TVDB ID");
	show = tvdb.Series(tvdb_id)
	#connection
	try:
		response = show.info()
	except (HTTPError, ConnectionError) as err:
		return (None, "Method get_IMDb_ID_from_theTVDB - " + str(err))
	#result
	try:
		imdb_id = show.imdbId
	except:
		imdb_id = None
		pass
	#no IMDb ID
	if imdb_id == None or imdb_id == "":
		return (None, "Method get_IMDb_ID_from_theTVDB - TVDB ID: " + str(tvdb_id) + " -> missing IMDb ID")
	#special cases
	if "tt" not in imdb_id: imdb_id = "tt" + str(imdb_id)
	imdb_id = imdb_id.rstrip('/')
	return (imdb_id, "OK")
