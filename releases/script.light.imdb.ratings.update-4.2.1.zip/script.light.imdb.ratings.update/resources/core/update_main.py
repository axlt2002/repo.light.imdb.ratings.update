# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################

import xbmc, xbmcgui
import sys
from datetime import datetime
from operator import truediv
if sys.version_info >= (2, 7): import json as jSon
else: import simplejson as jSon
from common import *
from update_common import *
from imdb_scraper import parse_IMDb_page
from thread import start_new_thread, allocate_lock

max_threads = int(NumberOfThreads) - 1	#0 - 1 thread, 1 - 2 threads ...
num_threads = 0

def thread_parse_IMDb_page(updateitem, updateitem_id, IMDb, TVDB, TMDB, title, season, progress, percentage, lock, flock):
	global num_threads
	if updateitem == "movie" or updateitem == "tvshow":
		(updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
		if updatedRating == None:
			sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
			flock.acquire()
			try:
				statusLog( title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: "+ sTMDB + ")" + "\n" + statusInfo )
				if ShowLogMessage == "true":
					addonSettings.setSetting( "LogDialog", "true" )
			finally:
				flock.release()
		else:
			if updateitem == "movie":
				jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str( updateitem_id ) + ',"ratings":{"imdb":{"rating":' + str( updatedRating ) + ',"votes":' + str( updatedVotes ).replace(",", "") + ',"default":' + IMDbDefault + '}},"top250":' + str( updatedTop250 ) + '},"id":1}'
			elif updateitem == "tvshow":
				jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( updateitem_id ) + ',"ratings":{"imdb":{"rating":' + str( updatedRating ) + ',"votes":' + str( updatedVotes ).replace(",", "") + ',"default":' + IMDbDefault + '}}},"id":1}'
			jSonResponse = xbmc.executeJSONRPC( jSonQuery )
	elif updateitem == "season":
		doUpdateEpisodesBySeason(updateitem_id, IMDb, season, progress, percentage, flock)
	lock.acquire()
	num_threads -= 1
	lock.release()
	return

class Movies:
	def __init__(self):
		self.AllMovies = []
		self.getDBMovies()
		if len( self.AllMovies ) == 0:
			return
		if ShowNotifications == "true":
			doNotify( addonLanguage(32255), 5000 )
			xbmc.sleep(5000)
		statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled ratings update for movies started (NumberOfThreads: " + str(NumberOfThreads) + ")" )
		self.lock = allocate_lock()
		self.flock = allocate_lock()
		self.doUpdate()
		statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled ratings update for movies finished" )
		if ShowNotifications == "true":
			doNotify( addonLanguage(32258), 5000 )
			xbmc.sleep(8000)
		return

	def getDBMovies(self):
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies","params":{"properties":["uniqueid","title"]},"id":1}'
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		jSonResponse = jSon.loads( jSonResponse )
		try:
			if jSonResponse['result'].has_key( 'movies' ):
				for item in jSonResponse['result']['movies']:
					movieid = item.get('movieid'); unique_id = item.get('uniqueid'); IMDb = unique_id.get('imdb'); title = item.get('title'); 
					TVDB = unique_id.get('tvdb'); TMDB = unique_id.get('tmdb');
					self.AllMovies.append((movieid, IMDb, TVDB, TMDB, title))
		except: pass
		return

	def doUpdate(self):
		global num_threads
		AllMovies = len( self.AllMovies ); Counter = 0;
		progress = None
		if ShowProgress == "true":
			progress = xbmcgui.DialogProgressBG()
			progress.create( addonLanguage(32260) )
		for Movie in self.AllMovies:
			while num_threads > max_threads*2:
				xbmc.sleep(500)
			if ShowProgress == "true":
				Counter = Counter + 1
				progress.update( (Counter*100)/AllMovies, addonLanguage(32260), Movie[4] )
			if Movie[1] == None:
				statusInfo = "Missing IMDb ID"
				sIMDb, sTVDB, sTMDB = printable_IDs(Movie[1], Movie[2], Movie[3])
				self.flock.acquire()
				try:
					statusLog( Movie[4] + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: "+ sTMDB + ")" + "\n" + statusInfo )
					if ShowLogMessage == "true":
						addonSettings.setSetting( "LogDialog", "true" )
				finally:
					self.flock.release()
				continue
			start_new_thread(thread_parse_IMDb_page,("movie", Movie[0], Movie[1], Movie[2], Movie[3], Movie[4], -1, progress, 0, self.lock, self.flock))
			self.lock.acquire()
			num_threads += 1
			self.lock.release()
		while num_threads > 0:
			xbmc.sleep(500)
		if ShowProgress == "true":
			xbmc.sleep(1000)
			progress.close()
		return

class TVShows:
	def __init__(self):
		self.AllTVShows = []
		self.getDBTVShows()
		if len( self.AllTVShows ) == 0:
			return
		if ShowNotifications == "true":
			doNotify( addonLanguage(32256), 5000 )
			xbmc.sleep(5000)
		statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled ratings update for TV shows started (NumberOfThreads: " + str(NumberOfThreads) + ")" )
		self.lock = allocate_lock()
		self.flock = allocate_lock()
		self.doUpdateTVShows()
		statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled ratings update for TV shows finished" )
		if ShowNotifications == "true":
			doNotify( addonLanguage(32259), 5000 )
			xbmc.sleep(5000)
		return

	def getDBTVShows(self):
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"]},"id":1}'
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		jSonResponse = jSon.loads( jSonResponse )
		try:
			if jSonResponse['result'].has_key( 'tvshows' ):
				for item in jSonResponse['result']['tvshows']:
					tvshowid = item.get('tvshowid'); unique_id = item.get('uniqueid'); IMDb = unique_id.get('imdb'); title = item.get('title');
					TVDB = unique_id.get('tvdb'); TMDB = unique_id.get('tmdb');
					self.AllTVShows.append((tvshowid, IMDb, TVDB, TMDB, title))
		except: pass
		return

	def doUpdateTVShows(self):
		global num_threads
		AllTVShows = len( self.AllTVShows ); Counter = 0;
		PCounter = 0
		progress = None
		if ShowProgress == "true":
			self.progress = xbmcgui.DialogProgressBG()
			self.progress.create( addonLanguage(32260) )
		for TVShow in self.AllTVShows:
			while num_threads > max_threads:
				xbmc.sleep(500)
			if ShowProgress == "true":
				Counter = Counter + 1
				PCounter = (Counter*100)/AllTVShows
				self.progress.update( PCounter, addonLanguage(32260), TVShow[4] )
			IMDb = TVShow[1]
			if IMDb == None:
				IMDb, statusInfo = get_tvshow_IMDb_ID("tvshow", TVShow[0], TVShow[2], TVShow[3], TVShow[4])
			if IMDb == None:
				sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVShow[2], TVShow[3])
				self.flock.acquire()
				try:
					statusLog( TVShow[4] + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: "+ sTMDB + ")" + "\n" + statusInfo )
					if ShowLogMessage == "true":
						addonSettings.setSetting( "LogDialog", "true" )
				finally:
					self.flock.release()
				continue
			start_new_thread(thread_parse_IMDb_page,("tvshow", TVShow[0], IMDb, TVShow[2], TVShow[3], TVShow[4], -1, self.progress, 0, self.lock, self.flock))
			self.lock.acquire()
			num_threads += 1
			self.lock.release()
			if IncludeEpisodes == "true":
				self.doUpdateSeasons(TVShow[0], IMDb, self.progress, PCounter)
		while num_threads > 0:
			xbmc.sleep(500)
		if ShowProgress == "true":
			xbmc.sleep(1000)
			self.progress.close()
		return

	def doUpdateSeasons(self, tvshowid, IMDb, progress, percentage):
		global num_threads
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetSeasons","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["season"]},"id":1}'
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		jSonResponse = jSon.loads( jSonResponse )
		try:
			if jSonResponse['result'].has_key( 'seasons' ):
				seasons = jSonResponse['result']['seasons']
				for item in seasons:
					while num_threads > max_threads:
						xbmc.sleep(500)
					start_new_thread(thread_parse_IMDb_page,("season", tvshowid, IMDb, None, None, "", item.get('season'), progress, percentage, self.lock, self.flock))
					self.lock.acquire()
					num_threads += 1
					self.lock.release()
		except: pass
		return

def perform_update():
	if not wait_for_internet(wait=3, retry=1):
		xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32257) )
		return
	if addonSettings.getSetting( "PerformingUpdate" ) == "true":
		xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32251) )
		return
	addonSettings.setSetting( "PerformingUpdate", "true" )
	if onMovies == "true":
		Movies()
	if onTVShows == "true":
		TVShows()
	addonSettings.setSetting( "PerformingUpdate", "false" )
	if ShowLogMessage == "true" and addonSettings.getSetting( "LogDialog") == "true":
		xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32824) )
		addonSettings.setSetting( "LogDialog", "false" )
	return