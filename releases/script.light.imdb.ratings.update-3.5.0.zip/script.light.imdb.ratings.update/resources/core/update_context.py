# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################
# changes by dziobak        #
#############################

import xbmc, xbmcgui
import sys, re
import math
if sys.version_info >= (2, 7): import json as jSon
else: import simplejson as jSon
from common import *
from imdb_scraper import parse_IMDb_page
from tvdb_scraper import get_IMDb_ID_from_theTVDB
from tmdb_scraper import get_IMDb_ID_from_TMDb
	
def open_context_menu( filename, label ):
	updateitem = ""
	movieid = -1; episodeid = -1; seasonid = -1; tvshowid = -1
	rating = -1; votes = -1; top250 = -1
	Title = ""
	IMDb = ""; TVDB = ""; TMDB = ""
	season = ""
	episode = ""
	filename = filename.replace("/"," ")
	id_parts = re.findall(r"[+-]?\d+(?:\.\d+)?", filename)
	if "movies" in filename:
		updateitem = "movie"
		movieid = int(id_parts[0])
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":' + str( movieid ) + ',"properties":["imdbnumber","ratings","top250"]},"id":1}'
	elif "tvshows" in filename and "season" in filename and "tvshowid" in filename:
		updateitem = "episode"
		episodeid = int(id_parts[2])
		seasonid = int(id_parts[1])
		tvshowid = int(id_parts[0])
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"properties":["uniqueid","ratings","episode","season","showtitle"]},"id":1}'
	elif "tvshows" in filename and "tvshowid" in filename:
		seasonid = int(id_parts[1])
		tvshowid = int(id_parts[0])
		if seasonid == -1:
			updateitem = "episode"
			episodeid = int(id_parts[2])
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"properties":["uniqueid","ratings","episode","season","showtitle"]},"id":1}'
		else:
			updateitem = "season"
	elif "tvshows" in filename:
		updateitem = "tvshow"
		tvshowid = int(id_parts[0])
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["uniqueid","ratings"]},"id":1}'
	if updateitem != "season":
		debugLog( "JSON Query: " + jSonQuery )
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		debugLog( "JSON Response: " + jSonResponse )
		jSonResponse = jSon.loads( jSonResponse )
		if jSonResponse['result'].has_key( 'moviedetails' ):
			item = jSonResponse['result']['moviedetails']
			IMDb = item.get('imdbnumber')
			Title = item.get('label')
			ratings = item.get('ratings')
			imdb = ratings.get('imdb')
			if imdb != None:
				rating = imdb.get('rating')
				votes = imdb.get('votes')
			top250 = item.get('top250')
		elif jSonResponse['result'].has_key( 'episodedetails' ):
			item = jSonResponse['result']['episodedetails']
			unique_id = item.get('uniqueid')
			IMDb = unique_id.get('imdb')
			TVDB = unique_id.get('tvdb')
			TMDB = unique_id.get('tmdb')
			season = item.get('season')
			episode = "%02d"%item.get('episode')
			Title = item.get('showtitle').encode('utf-8') + " " + str( season ) + "x" + str( episode )
			Title = Title.decode('utf-8')
			ratings = item.get('ratings')
			imdb = ratings.get('imdb')
			if imdb != None:
				rating = imdb.get('rating')
				votes = imdb.get('votes')
		elif jSonResponse['result'].has_key( 'tvshowdetails' ):
			item = jSonResponse['result']['tvshowdetails']
			unique_id = item.get('uniqueid')
			IMDb = unique_id.get('imdb')
			TVDB = unique_id.get('tvdb')
			TMDB = unique_id.get('tmdb')
			Title = item.get('label')
			ratings = item.get('ratings')
			imdb = ratings.get('imdb')
			if imdb != None:
				rating = imdb.get('rating')
				votes = imdb.get('votes')
	else:
		Title = label
	defaultLog( addonLanguage(32521) % Title )
	context_menu_options(updateitem, movieid, episodeid, seasonid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, rating, votes, top250)

def context_menu_options(updateitem, movieid, episodeid, seasonid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, rating, votes, top250):
	option = -1
	while True:
		if IMDb == "" or IMDb == None:
			IMDb = addonLanguage(32528)
		if TVDB == "" or TVDB == None:
			TVDB = addonLanguage(32528)
		if TMDB == "" or TMDB == None:
			TMDB = addonLanguage(32528)
		stringList = []
		if updateitem != "season":
			if rating != -1:
				rating = round(rating, 2)
				stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(addonLanguage(32263) + ": ", str(rating) + " (" + str(votes) + " " + addonLanguage(32264) + ")") ]
			else:
				stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(addonLanguage(32263) + ": ", addonLanguage(32528)) ]
		if updateitem == "movie" and top250 != 0 and top250 != None:
			stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(addonLanguage(32265) + ": ", str(top250)) ]
		stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32252)) ]
		if updateitem != "season":
			stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("IMDb ID: ", IMDb) ]
			stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32517)) ]
		if updateitem != "season" and updateitem != "movie":
			stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("TMDB ID: ", TMDB) ]
			stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32523)) ]
			stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("TVDB ID: ", TVDB) ]
			stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32518)) ]
		menu_items = len(stringList)
		option = xbmcgui.Dialog().select(addonName, stringList)
		if option == -1:
			return
		if (option == 0 and menu_items != 1) or (option == 1 and menu_items == 5):
			continue
		elif (option == 1 and menu_items == 4) or (option == 2 and menu_items == 5) or (option == 1 and menu_items == 8) or (option == 0 and menu_items == 1):
			ret1, ret2, ret3, ret4 = doUpdateItem(updateitem, movieid, episodeid, seasonid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title)
			if not (ret1 == -1 and ret2 == -1 and ret3 == -1):
				rating = ret1
				votes = ret2
				top250 = ret3
			if ret4 != "":
				IMDb = ret4
			if (menu_items == 1):
				return
			else:
				continue
		elif (option == 2 and menu_items != 5) or (option == 3 and menu_items == 5):
			defaultLog( addonLanguage(32513) % ( Title ) )
			new_IMDb = xbmcgui.Dialog().input( "IMDb ID", IMDb )
			if new_IMDb != "":
				IMDb = new_IMDb
				defaultLog( addonLanguage(32515) % ( Title, IMDb ) )
		elif (option == 3 and menu_items != 5) or (option == 4 and menu_items == 5):
			IMDb = addonLanguage(32528)
			defaultLog( addonLanguage(32519) % ( Title ) )
		elif option == 4:
			defaultLog( addonLanguage(32525) % ( Title ) )
			new_TMDB = xbmcgui.Dialog().input( "TMDB ID", TMDB )
			if new_TMDB != "":
				TMDB =  new_TMDB
				defaultLog( addonLanguage(32526) % ( Title, TMDB ) )
		elif option == 5:
			TMDB = addonLanguage(32528)
			defaultLog( addonLanguage(32524) % ( Title ) )
		elif option == 6:
			defaultLog( addonLanguage(32514) % ( Title ) )
			new_TVDB = xbmcgui.Dialog().input( "TVDB ID", TVDB )
			if new_TVDB != "":
				TVDB =  new_TVDB
				defaultLog( addonLanguage(32516) % ( Title, TVDB ) )
		elif option == 7:
			TVDB = addonLanguage(32528)
			defaultLog( addonLanguage(32520) % ( Title ) )
		if updateitem == "movie":
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str( movieid ) + ',"imdbnumber": "' + IMDb + '","uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
		elif updateitem == "episode":
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '","tmdb": "' + TMDB + '"}},"id":1}'
		elif updateitem == "tvshow":
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '","tmdb": "' + TMDB + '"}},"id":1}'
		debugLog( "JSON Query: " + jSonQuery )
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		debugLog( "JSON Response: " + jSonResponse )

def doUpdateItem(updateitem, movieid, episodeid, seasonid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title):
	if addonSettings.getSetting( "PerformingUpdate" ) == "true":
		xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32251) )
		return -1, -1, -1, ""
	addonSettings.setSetting( "PerformingUpdate", "true" )
	seasonpisodes = False
	allepisodes = False
	if updateitem == "season":
		dialog = xbmcgui.Dialog()
		seasonpisodes = dialog.yesno( "%s" % ( addonName ), addonLanguage(32508) )
		if seasonpisodes == True:
			Progress = xbmcgui.DialogProgressBG()
			Progress.create( addonLanguage(32260), Title )
			doUpdateEpisodes( Progress, tvshowid, seasonid )
			xbmc.sleep(1000)
			Progress.close()	
		addonSettings.setSetting( "PerformingUpdate", "false" )
		return -1, -1, -1, ""
	if updateitem == "tvshow":
		dialog = xbmcgui.Dialog()
		allepisodes = dialog.yesno( "%s" % ( addonName ), addonLanguage(32253) )
	Progress = xbmcgui.DialogProgressBG()
	Progress.create( addonLanguage(32260), Title )
	exit = False
	if IMDb == None or IMDb == "" or "tt" not in IMDb: IMDb = None
	if updateitem == "movie":
		TVDB = None
		TMDB = None
	defaultLog( addonLanguage(32507) % ( Title, IMDb, TVDB, TMDB ) )
	if IMDb == None:
		if (updateitem != "movie"):
			(IMDb, statusInfo) = get_IMDb_ID_from_theTVDB(updateitem, TVDB)
			if IMDb == None:
				if (updateitem == "episode"):
					jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["uniqueid"]},"id":1}'
					debugLog( "JSON Query: " + jSonQuery )
					jSonResponse = xbmc.executeJSONRPC( jSonQuery )
					jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
					debugLog( "JSON Response: " + jSonResponse )
					jSonResponse = jSon.loads( jSonResponse )
					item = jSonResponse['result']['tvshowdetails']
					unique_id = item.get('uniqueid')
					TMDB = unique_id.get('tmdb')
				(IMDb, add_statusInfo) = get_IMDb_ID_from_TMDb(updateitem, TMDB, season, episode)
				statusInfo = statusInfo + "\n" + add_statusInfo
		else:
			statusInfo = "Missing IMDb ID"
	if IMDb == None:
		defaultLog( addonLanguage(32503) % ( Title ) )
		statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ":\n" + statusInfo )
		exit = True
	else:
		(updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
		if updatedRating == None:
			defaultLog( addonLanguage(32503) % ( Title ) )
			statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ":\n" + statusInfo )
			exit = True
	if exit == True:
		if allepisodes == True:
			doUpdateEpisodes( Progress, tvshowid, seasonid )
		else:
			Progress.update( 100, addonLanguage(32260), Title )
		xbmc.sleep(1000)
		Progress.close()
		addonSettings.setSetting( "PerformingUpdate", "false" )
		return -1, -1, -1, ""
	if updateitem != "movie":
		updatedTop250 = None
	imdb_default = addonSettings.getSetting( "IMDbRatingDefault" )
	if updateitem == "movie":
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str( movieid ) + ',"ratings":{"imdb":{"rating":' + str( updatedRating ) + ',"votes":' + str( updatedVotes ).replace(",", "") + ',"default":' + imdb_default + '}},"top250":' + str( updatedTop250 ) + '},"id":1}'
	elif updateitem == "tvshow":
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"ratings":{"imdb":{"rating":' + str( updatedRating ) + ',"votes":' + str( updatedVotes ).replace(",", "") + ',"default":' + imdb_default + '}},"uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
	elif updateitem == "episode":
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"ratings":{"imdb":{"rating":' + str( updatedRating ) + ',"votes":' + str( updatedVotes ).replace(",", "") + ',"default":' + imdb_default + '}},"uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
	debugLog( "JSON Query: " + jSonQuery )
	jSonResponse = xbmc.executeJSONRPC( jSonQuery )
	jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
	debugLog( "JSON Response: " + jSonResponse )
	defaultLog( addonLanguage(32500) % ( Title, str( updatedRating ), str( updatedVotes ), str( updatedTop250 ) ) )
	if allepisodes == True:
		doUpdateEpisodes( Progress, tvshowid, seasonid )
	else:
		Progress.update( 100, addonLanguage(32260), Title )
	xbmc.sleep(1000)
	Progress.close()
	addonSettings.setSetting( "PerformingUpdate", "false" )
	return float(updatedRating), updatedVotes.replace(",", ""), updatedTop250, IMDb

def doUpdateEpisodes( progress, tvshowid, seasonid ):
	if seasonid == -1:
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{"tvshowid":' + str( tvshowid ) + ', "properties":["uniqueid","episode","season","showtitle"]},"id":1}'
	else:
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{"tvshowid":' + str( tvshowid ) + ', "season":' + str( seasonid ) + ', "properties":["uniqueid","episode","season","showtitle"]},"id":1}'
	debugLog( "JSON Query: " + jSonQuery )
	jSonResponse = xbmc.executeJSONRPC( jSonQuery )
	jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
	debugLog( "JSON Response: " + jSonResponse )
	jSonResponse = jSon.loads( jSonResponse )
	try:
		if jSonResponse['result'].has_key( 'episodes' ):
			Counter = 0
			AllEpisodes = jSonResponse['result']['limits']['total']
			for item in jSonResponse['result']['episodes']:
				TVDB = ""
				TMDB = ""
				Counter = Counter + 1
				EpisodeID = item.get('episodeid'); unique_id = item.get('uniqueid'); IMDb = unique_id.get('imdb')
				Title = item.get('showtitle').encode('utf-8') + " " + str( item.get('season') ) + "x" + str( "%02d" % item.get('episode') )
				Title = Title.decode('utf-8')
				TVDB = unique_id.get('tvdb')
				TMDB = unique_id.get('tmdb')
				progress.update( (Counter*100)/AllEpisodes, addonLanguage(32260), Title )
				if IMDb == None or IMDb == "" or "tt" not in IMDb: IMDb = None
				defaultLog( addonLanguage(32507) % ( Title, IMDb, TVDB, TMDB ) )
				if IMDb == None:
					(IMDb, statusInfo) = get_IMDb_ID_from_theTVDB("episode", TVDB)
					if IMDb == None:
						jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["uniqueid"]},"id":1}'
						debugLog( "JSON Query: " + jSonQuery )
						jSonResponse = xbmc.executeJSONRPC( jSonQuery )
						jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
						debugLog( "JSON Response: " + jSonResponse )
						jSonResponse = jSon.loads( jSonResponse )
						item_tvshow = jSonResponse['result']['tvshowdetails']
						unique_id = item_tvshow.get('uniqueid')
						TMDB = unique_id.get('tmdb')
						(IMDb, add_statusInfo) = get_IMDb_ID_from_TMDb("episode", TMDB, item.get('season'), item.get('episode'))
						statusInfo = statusInfo + "\n" + add_statusInfo
				if IMDb == None:
					statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ":\n" + statusInfo )
					continue
				(updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
				if updatedRating == None:
					defaultLog( addonLanguage(32503) % ( Title ) )
					statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ":\n" + statusInfo )
					continue
				updatedTop250 = None
				imdb_default = addonSettings.getSetting( "IMDbRatingDefault" )
				jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str( EpisodeID ) + ',"ratings":{"imdb":{"rating":' + str( updatedRating ) + ',"votes":' + str( updatedVotes ).replace(",", "") + ',"default":' + imdb_default + '}},"uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
				debugLog( "JSON Query: " + jSonQuery )
				jSonResponse = xbmc.executeJSONRPC( jSonQuery )
				jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
				debugLog( "JSON Response: " + jSonResponse )
				defaultLog( addonLanguage(32500) % ( Title, str( updatedRating ), str( updatedVotes ), str( updatedTop250 ) ) )
	except: pass
