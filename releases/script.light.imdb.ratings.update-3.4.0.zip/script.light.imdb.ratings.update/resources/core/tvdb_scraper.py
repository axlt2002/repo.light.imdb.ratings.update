# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################
# changes by dziobak        #
#############################

from common import *
from requests.exceptions import HTTPError
from requests.exceptions import ConnectionError
import resources.support.tvdbsimple as tvdb
tvdb.KEYS.API_KEY = "53F49B260156B636"

def get_IMDb_ID_from_theTVDB(updateitem, tvdb_id):
	if tvdb_id == "" or tvdb_id == None or tvdb_id == "None":
		return (None, "Method get_IMDb_ID_from_theTVDB: Missing TVDB ID");
	defaultLog( addonLanguage(32509) )
	if updateitem == "tvshow":
		show = tvdb.Series(tvdb_id)
	elif updateitem == "episode":
		show = tvdb.Episode(tvdb_id)
	#connection
	try:
		response = show.info()
	except (HTTPError, ConnectionError) as err:
		defaultLog( addonLanguage(32510) + str(err) )
		return (None, "Method get_IMDb_ID_from_theTVDB: " + str(err))
	#result
	try:
		imdb_id = show.imdbId
	except:
		imdb_id = None
		pass
	#no IMDb ID
	if imdb_id == None or imdb_id == "":
		defaultLog( addonLanguage(32511) )
		return (None, "Method get_IMDb_ID_from_theTVDB: TVDB " + str(tvdb_id) + " (" + updateitem + ") -> missing IMDb ID")
	#special cases
	if "tt" not in imdb_id: imdb_id = "tt" + str(imdb_id)
	imdb_id = imdb_id.rstrip('/')
	defaultLog( addonLanguage(32512) % ( imdb_id ) )
	return (imdb_id, "OK")
