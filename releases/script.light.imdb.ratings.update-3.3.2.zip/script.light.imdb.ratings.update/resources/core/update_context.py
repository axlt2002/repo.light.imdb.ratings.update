# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################
# changes by dziobak        #
#############################

import xbmc, xbmcgui
import sys, re
if sys.version_info >= (2, 7): import json as jSon
else: import simplejson as jSon
from common import *
from imdb_scraper import parse_IMDb_page
from tvdb_scraper import get_IMDb_ID
	
def open_context_menu( filename, label ):
	updateitem = ""
	movieid = -1; episodeid = -1; seasonid = -1; tvshowid = -1
	Title = ""
	IMDb = ""; TVDB = ""
	filename = filename.replace("/"," ")
	id_parts = re.findall(r"[+-]?\d+(?:\.\d+)?", filename)
	if "movies" in filename:
		updateitem = "movie"
		movieid = int(id_parts[0])
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":' + str( movieid ) + ',"properties":["imdbnumber","rating","votes","top250"]},"id":1}'
	elif "tvshows" in filename and "season" in filename and "tvshowid" in filename:
		updateitem = "episode"
		episodeid = int(id_parts[2])
		seasonid = int(id_parts[1])
		tvshowid = int(id_parts[0])
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"properties":["uniqueid","rating","votes","episode","season","showtitle"]},"id":1}'
	elif "tvshows" in filename and "tvshowid" in filename:
		seasonid = int(id_parts[1])
		tvshowid = int(id_parts[0])
		if seasonid == -1:
			updateitem = "episode"
			episodeid = int(id_parts[2])
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"properties":["uniqueid","rating","votes","episode","season","showtitle"]},"id":1}'
		else:
			updateitem = "season"
	elif "tvshows" in filename:
		updateitem = "tvshow"
		tvshowid = int(id_parts[0])
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["imdbnumber","uniqueid","rating","votes"]},"id":1}'
	if updateitem != "season":
		debugLog( "JSON Query: " + jSonQuery )
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		debugLog( "JSON Response: " + jSonResponse )
		jSonResponse = jSon.loads( jSonResponse )
		if jSonResponse['result'].has_key( 'moviedetails' ):
			item = jSonResponse['result']['moviedetails']
			IMDb = item.get('imdbnumber')
			Title = item.get('label')
		elif jSonResponse['result'].has_key( 'episodedetails' ):
			item = jSonResponse['result']['episodedetails']
			unique_id = item.get('uniqueid')
			IMDb = unique_id.get('imdb')
			TVDB = unique_id.get('tvdb')
			if TVDB == "" or TVDB == None:
				TVDB = unique_id.get('unknown')
			Title = item.get('showtitle').encode('utf-8') + " " + str( item.get('season') ) + "x" + str( "%02d" % item.get('episode') )
			Title = Title.decode('utf-8')
		elif jSonResponse['result'].has_key( 'tvshowdetails' ):
			item = jSonResponse['result']['tvshowdetails']
			unique_id = item.get('uniqueid')
			IMDb = unique_id.get('imdb')
			TVDB = item.get('imdbnumber')
			Title = item.get('label')
	else:
		Title = label
	defaultLog( addonLanguage(32521) % Title )
	(update, IMDb, TVDB) = context_menu_options(updateitem, movieid, episodeid, seasonid, tvshowid, IMDb, TVDB, Title)
	if update == "true":
		doUpdateItem(updateitem, movieid, episodeid, seasonid, tvshowid, IMDb, TVDB, Title)

def context_menu_options(updateitem, movieid, episodeid, seasonid, tvshowid, IMDb, TVDB, Title):
	option = -1
	while(option != 0):
		if IMDb == "" or IMDb == None:
			IMDb = "None"
		if TVDB == "" or TVDB == None:
			TVDB = "None"
		stringList = []
		stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32252)) ]
		if updateitem != "season":
			stringList += [ "[COLOR white]{0}[/COLOR][COLOR skyblue]{1}[/COLOR]".format("IMDb ID: ", IMDb) ]
			stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32517)) ]
		if updateitem != "season" and updateitem != "movie":
			stringList += [ "[COLOR white]{0}[/COLOR][COLOR skyblue]{1}[/COLOR]".format("TVDB ID: ", TVDB) ]
			stringList += [ "[COLOR white]{0}[/COLOR]".format(addonLanguage(32518)) ]
		option = xbmcgui.Dialog().select(addonName, stringList)
		if option == -1:
			return ("false", IMDb, TVDB)
		elif option == 0:
			return ("true", IMDb, TVDB)
		elif option == 1:
			defaultLog( addonLanguage(32513) % ( Title ) )
			new_IMDb = xbmcgui.Dialog().input( "IMDb ID", IMDb )
			if new_IMDb != "":
				IMDb = new_IMDb
				defaultLog( addonLanguage(32515) % ( Title, IMDb ) )
		elif option == 2:
			IMDb = "None"
			defaultLog( addonLanguage(32519) % ( Title ) )
		elif option == 3:
			defaultLog( addonLanguage(32514) % ( Title ) )
			new_TVDB = xbmcgui.Dialog().input( "TVDB ID", TVDB )
			if new_TVDB != "":
				TVDB =  new_TVDB
				defaultLog( addonLanguage(32516) % ( Title, TVDB ) )
		elif option == 4:
			TVDB = "None"
			defaultLog( addonLanguage(32520) % ( Title ) )
		if updateitem == "movie":
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str( movieid ) + ',"imdbnumber": "' + IMDb + '","uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
		elif updateitem == "episode":
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '","unknown": "' + TVDB + '"}},"id":1}'
		elif updateitem == "tvshow":
			jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"imdbnumber": "' + TVDB + '","uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '"}},"id":1}'
		debugLog( "JSON Query: " + jSonQuery )
		jSonResponse = xbmc.executeJSONRPC( jSonQuery )
		jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
		debugLog( "JSON Response: " + jSonResponse )

def doUpdateItem(updateitem, movieid, episodeid, seasonid, tvshowid, IMDb, TVDB, Title):
	if addonSettings.getSetting( "PerformingUpdate" ) == "true":
		xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32251) )
		return
	addonSettings.setSetting( "PerformingUpdate", "true" )
	seasonpisodes = False
	allepisodes = False
	if updateitem == "season":
		dialog = xbmcgui.Dialog()
		seasonpisodes = dialog.yesno( "%s" % ( addonName ), addonLanguage(32508) )
		if seasonpisodes == True:
			Progress = xbmcgui.DialogProgressBG()
			Progress.create( addonLanguage(32260), Title )
			doUpdateEpisodes( Progress, tvshowid, seasonid )
			xbmc.sleep(1000)
			Progress.close()	
		addonSettings.setSetting( "PerformingUpdate", "false" )
		return
	if updateitem == "tvshow":
		dialog = xbmcgui.Dialog()
		allepisodes = dialog.yesno( "%s" % ( addonName ), addonLanguage(32253) )
	Progress = xbmcgui.DialogProgressBG()
	Progress.create( addonLanguage(32260), Title )
	exit = False
	if IMDb == None or IMDb == "" or "tt" not in IMDb: IMDb = None
	if updateitem == "movie":
		TVDB = None
	defaultLog( addonLanguage(32507) % ( Title, IMDb, TVDB ) )
	if IMDb == None:
		if (updateitem != "movie"):
			(IMDb, statusInfo) = get_IMDb_ID(updateitem, TVDB)
		else:
			statusInfo = "Missing IMDb ID"
	if IMDb == None:
		defaultLog( addonLanguage(32503) % ( Title ) )
		statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ": " + statusInfo )
		exit = True
	else:	
		(updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
		if updatedRating == None:
			defaultLog( addonLanguage(32503) % ( Title ) )
			statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ": " + statusInfo )
			exit = True
	if exit == True:
		if allepisodes == True:
			doUpdateEpisodes( Progress, tvshowid, seasonid )
		else:
			Progress.update( 100, addonLanguage(32260), Title )
		xbmc.sleep(1000)
		Progress.close()
		addonSettings.setSetting( "PerformingUpdate", "false" )
		return
	if updateitem != "movie":
		updatedTop250 = None
	if updateitem == "movie":
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str( movieid ) + ',"rating":' + str( updatedRating ) + ',"votes":"' + str( updatedVotes ) + '","top250":' + str( updatedTop250 ) + '},"id":1}'
	elif updateitem == "tvshow":
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"imdbnumber": "' + TVDB + '","rating":' + str( updatedRating ) + ',"votes":"' + str( updatedVotes ) + '","uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '"}},"id":1}'
	elif updateitem == "episode":
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str( episodeid ) + ',"rating":' + str( updatedRating ) + ',"votes":"' + str( updatedVotes ) + '","uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '","unknown": "' + TVDB + '"}},"id":1}'
	debugLog( "JSON Query: " + jSonQuery )
	jSonResponse = xbmc.executeJSONRPC( jSonQuery )
	jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
	debugLog( "JSON Response: " + jSonResponse )
	defaultLog( addonLanguage(32500) % ( Title, str( updatedRating ), str( updatedVotes ), str( updatedTop250 ) ) )
	if allepisodes == True:
		doUpdateEpisodes( Progress, tvshowid, seasonid )
	else:
		Progress.update( 100, addonLanguage(32260), Title )
	xbmc.sleep(1000)
	Progress.close()
	addonSettings.setSetting( "PerformingUpdate", "false" )

def doUpdateEpisodes( progress, tvshowid, seasonid ):
	if seasonid == -1:
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{"tvshowid":' + str( tvshowid ) + ', "properties":["uniqueid","rating","votes","episode","season","showtitle"]},"id":1}'
	else:
		jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{"tvshowid":' + str( tvshowid ) + ', "season":' + str( seasonid ) + ', "properties":["uniqueid","rating","votes","episode","season","showtitle"]},"id":1}'
	debugLog( "JSON Query: " + jSonQuery )
	jSonResponse = xbmc.executeJSONRPC( jSonQuery )
	jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
	debugLog( "JSON Response: " + jSonResponse )
	jSonResponse = jSon.loads( jSonResponse )
	try:
		if jSonResponse['result'].has_key( 'episodes' ):
			Counter = 0
			AllEpisodes = jSonResponse['result']['limits']['total']
			for item in jSonResponse['result']['episodes']:
				TVDB = ""
				Counter = Counter + 1
				EpisodeID = item.get('episodeid'); unique_id = item.get('uniqueid'); IMDb = unique_id.get('imdb')
				Title = item.get('showtitle').encode('utf-8') + " " + str( item.get('season') ) + "x" + str( "%02d" % item.get('episode') )
				Title = Title.decode('utf-8')
				TVDB = unique_id.get('tvdb')
				if TVDB == "" or TVDB == None:
					TVDB = unique_id.get('unknown')
				progress.update( (Counter*100)/AllEpisodes, addonLanguage(32260), Title )
				if IMDb == None or IMDb == "" or "tt" not in IMDb: IMDb = None
				defaultLog( addonLanguage(32507) % ( Title, IMDb, TVDB ) )
				if IMDb == None:
					(IMDb, statusInfo) = get_IMDb_ID("episode", TVDB)
				if IMDb == None:
					statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ": " + statusInfo )
					continue
				(updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
				if updatedRating == None:
					defaultLog( addonLanguage(32503) % ( Title ) )
					statusLog( "\n" + "--> " + addonLanguage(32257) + "\n" + Title + ": " + statusInfo )
					continue
				updatedTop250 = None
				jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str( EpisodeID ) + ',"rating":' + str( updatedRating ) + ',"votes":"' + str( updatedVotes ) + '","uniqueid": {"imdb": "' + IMDb + '","tvdb": "' + TVDB + '","unknown": "' + TVDB + '"}},"id":1}'
				debugLog( "JSON Query: " + jSonQuery )
				jSonResponse = xbmc.executeJSONRPC( jSonQuery )
				jSonResponse = unicode( jSonResponse, 'utf-8', errors='ignore' )
				debugLog( "JSON Response: " + jSonResponse )
				defaultLog( addonLanguage(32500) % ( Title, str( updatedRating ), str( updatedVotes ), str( updatedTop250 ) ) )
	except: pass
