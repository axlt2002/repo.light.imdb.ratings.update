# -*- coding: utf-8 -*-

#############################
# Light IMDb Ratings Update #
# by axlt2002               #
#############################
# changes by dziobak        #
#############################

from common import *
from requests.exceptions import HTTPError
from requests.exceptions import ConnectionError
import resources.support.tmdbsimple as tmdb
tmdb.API_KEY = "5a1a77e2eba8984804586122754f969f"

def get_IMDb_ID_from_TMDb(updateitem, tmdb_id, se_no, ep_no):
	if tmdb_id == "" or tmdb_id == None or tmdb_id == "None":
		return (None, "Method get_IMDb_ID_from_TMDb: Missing TMDB ID")
	defaultLog( addonLanguage(32522) )
	if updateitem == "tvshow":
		show = tmdb.TV(tmdb_id)
	elif updateitem == "episode":
		show = tmdb.TV_Episodes(tmdb_id, int(se_no), int(ep_no))		
	#connection
	try:
		response = show.external_ids()
	except (HTTPError, ConnectionError) as err:
		defaultLog( addonLanguage(32527) + str(err) )
		return (None, "Method get_IMDb_ID_from_TMDb: " + str(err))
	#result
	try:
		imdb_id = show.imdb_id
	except:
		imdb_id = None
		pass
	#no IMDb ID
	if imdb_id == None or imdb_id == "":
		defaultLog( addonLanguage(32511) )
		if updateitem == "tvshow":
			return (None, "Method get_IMDb_ID_from_TMDb: TMDB " + str(tmdb_id) + " (" + updateitem + ") -> missing IMDb ID")
		elif updateitem == "episode":
			return (None, "Method get_IMDb_ID_from_TMDb: TMDB " + str(tmdb_id) + " (" + updateitem + " " + str(se_no) + "x" + str(ep_no) + ") -> missing IMDb ID")
	defaultLog( addonLanguage(32512) % ( imdb_id ) )
	return (imdb_id, "OK")